package fut;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalTime;
import java.util.Arrays;
import java.util.LinkedList;
import static java.time.temporal.ChronoUnit.SECONDS;
import static java.time.temporal.ChronoUnit.MINUTES;

class BackgroundImageJFrame extends JFrame implements ActionListener, Runnable {
	private static final long serialVersionUID = 1L;// quita warning
	public JLabel pos;
	public JLabel acc;
	public JLabel tiempo;
	public JLabel reloj;
	public JLabel savedComnt;
	public JTextField comnt;
	public JTextField nombreFich;

	public LinkedList<DatosPartido> Datos = new LinkedList<DatosPartido>();
	public DatosPartido Cabecera = new DatosPartido("minuto", "posicion", "comentario", "accion");

	public JButton btn;
	public LinkedList<String> posiciones;
	int i = 0;
	public LocalTime horaInicio;

	public boolean empezado = false;

	public BackgroundImageJFrame() {
		Datos.add(Cabecera);

		setTitle("FUT-STATS");
		setSize(835, 547);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setVisible(true);
		setLayout(new BorderLayout());
		setContentPane(new JLabel(new ImageIcon(this.getClass().getResource("/images/fondo.jpeg"))));
		setLayout(new FlowLayout());
		setSize(399, 399);
		setSize(835, 547);

	}

	public void run() {

		// INICIALIZACION DE BOTONES DEL CAMPO
		LinkedList<DatosBoton> lista = completaLista();
		posiciones = new LinkedList<>();
		posiciones.addAll(Arrays.asList("AA", "AB", "AC", "BA", "BB", "BC", "BD", "CA", "CB", "CC", "CD", "EA", "EB",
				"FA", "FB", "DA", "DB"));
		pos = new JLabel();
		pos.setText("");
		pos.setBounds(70, 453, 20, 20);
		acc = new JLabel();
		acc.setText("");
		acc.setBounds(82, 476, 100, 20);
		tiempo = new JLabel();
		tiempo.setText("");
		tiempo.setBounds(347, 472, 160, 25);
		reloj = new JLabel();
		reloj.setText("");
		reloj.setBounds(635, 33, 160, 25);

		comnt = new JTextField();
		comnt.setBounds(600, 265, 150, 60);
		comnt.setName("coment");

		nombreFich = new JTextField();
		nombreFich.setBounds(600, 385, 150, 40);
		nombreFich.setName("nombre");

		savedComnt = new JLabel();
		savedComnt.setText("default");
		savedComnt.setBounds(385, 455, 100, 20);
		F.add(pos);
		F.add(acc);
		F.add(tiempo);
		F.add(reloj);
		F.add(comnt);
		F.add(savedComnt);
		F.add(nombreFich);

		F.setLayout(null);
		for (DatosBoton DB : lista) {

			F.add(DB.boton);

		}
		for (DatosBoton DB : lista) {
			if (posiciones.contains(DB.boton.getText())) {
				DB.boton.setOpaque(false);
				DB.boton.setContentAreaFilled(false);
				DB.boton.setBorderPainted(false);
			}
			DB.boton.addActionListener(this);

		}
		// BUCLE PRINCIPAL
		while (true) {
			try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
			}
			if (tiempo.getText() != "") {
				long min = MINUTES.between(horaInicio, LocalTime.now());

				long sec = SECONDS.between(horaInicio, LocalTime.now()) % 60;
				reloj.setText("MIN " + String.valueOf(min) + " SEC " + String.valueOf(sec));
			}

		}

	}

	public void actionPerformed(ActionEvent ae) {

		JComponent b = (JComponent) ae.getSource();

		for (String S : posiciones) {
			if (S.equals(((JButton) b).getText())) {
				pos.setText(((JButton) b).getText());
				long min = MINUTES.between(horaInicio, LocalTime.now());

				long sec = SECONDS.between(horaInicio, LocalTime.now()) % 60;
				tiempo.setText("MIN " + String.valueOf(min) + " SEC " + String.valueOf(sec));

			}
		}
		savedComnt.setText(comnt.getText());
		LinkedList<String> acciones = new LinkedList<>();

		if (((JButton) b).getText().equals("COMENZAR")) {
			if (!empezado) {
				empezado = true;
				horaInicio = LocalTime.now();
				long min = MINUTES.between(horaInicio, LocalTime.now());

				long sec = SECONDS.between(horaInicio, LocalTime.now()) % 60;
				tiempo.setText("MIN " + String.valueOf(min) + " SEC " + String.valueOf(sec));

			}

		}
		if (((JButton) b).getText().equals("+1")) {
			horaInicio = horaInicio.minusMinutes(1);
		}
		if (((JButton) b).getText().equals("-1")) {
			horaInicio = horaInicio.plusMinutes(1);

		}

		if (((JButton) b).getText().equals("GUARDAR")) {
			long min = MINUTES.between(horaInicio, LocalTime.now());

			long sec = SECONDS.between(horaInicio, LocalTime.now()) % 60;
			tiempo.setText("MIN " + String.valueOf(min) + " SEC " + String.valueOf(sec));

			DatosPartido d = new DatosPartido(tiempo.getText(), pos.getText(), savedComnt.getText(), acc.getText());
			Datos.add(d);
			savedComnt.setText(comnt.getText());
			BufferedWriter br = null;
			try {
				br = new BufferedWriter(new FileWriter(nombreFich.getText() + ".csv", false));
			} catch (IOException e) {
				e.printStackTrace();
			}
			StringBuilder sb = new StringBuilder();

			// Append strings from array
			for (DatosPartido element : Datos) {
				sb.append(element.Accion + " , " + element.Minuto + " , \"" + element.Coment + "\" , "
						+ element.Posicion + "\n");
			}

			try {
				br.write(sb.toString());
			} catch (IOException e) {
				e.printStackTrace();
			}
			try {
				br.close();
			} catch (IOException e) {
				e.printStackTrace();
			}

		}

		acciones.addAll(Arrays.asList("TIRO", "GOL", "FALTA","CAMBIO"));

		for (String S : acciones) {
			if (S.equals(((JButton) b).getText())) {
				acc.setText(((JButton) b).getText());
				long min = MINUTES.between(horaInicio, LocalTime.now());

				long sec = SECONDS.between(horaInicio, LocalTime.now()) % 60;
				tiempo.setText("MIN " + String.valueOf(min) + " SEC " + String.valueOf(sec));

			}
		}
	}

	public static LinkedList<DatosBoton> completaLista() {
		LinkedList<DatosBoton> l = new LinkedList<DatosBoton>();
		l.add(new DatosBoton(10, 7, 70, 20, "AA"));
		l.add(new DatosBoton(220, 7, 130, 35, "AB"));
		l.add(new DatosBoton(490, 7, 70, 20, "AC"));

		l.add(new DatosBoton(10, 25, 135, 85, "BA"));
		l.add(new DatosBoton(150, 25, 135, 85, "BB"));
		l.add(new DatosBoton(290, 25, 135, 85, "BC"));
		l.add(new DatosBoton(420, 25, 135, 85, "BD"));

		l.add(new DatosBoton(10, 105, 135, 55, "CA"));
		l.add(new DatosBoton(150, 105, 135, 55, "CB"));
		l.add(new DatosBoton(290, 105, 135, 55, "CC"));
		l.add(new DatosBoton(420, 105, 135, 55, "CD"));

		l.add(new DatosBoton(10, 160, 275, 85, "DA"));
		l.add(new DatosBoton(290, 160, 275, 85, "DB"));

		l.add(new DatosBoton(10, 245, 275, 55, "EA"));
		l.add(new DatosBoton(290, 245, 275, 55, "EB"));

		l.add(new DatosBoton(10, 300, 275, 135, "FA"));
		l.add(new DatosBoton(290, 300, 275, 135, "FB"));

		l.add(new DatosBoton(600, 10, 160, 25, "COMENZAR"));
		l.add(new DatosBoton(600, 55, 75, 20, "+1"));
		l.add(new DatosBoton(683, 55, 75, 20, "-1"));

		l.add(new DatosBoton(595, 130, 80, 25, "TIRO"));
		l.add(new DatosBoton(595, 160, 80, 25, "GOL"));
		l.add(new DatosBoton(595, 190, 80, 25, "FALTA"));
		l.add(new DatosBoton(677, 130, 93, 25, "CAMBIO"));


		l.add(new DatosBoton(600, 475, 160, 25, "GUARDAR"));

		return l;
	}

	public static BackgroundImageJFrame F = new BackgroundImageJFrame();

	public static void main(String args[]) {

		F.run();

	}

}