package fut;

public class DatosPartido {
	public String Minuto;
	public String Posicion;
	public String Coment;
	public String Accion;
	
	public DatosPartido(String minuto, String posicion, String coment, String accion) {
		super();
		Minuto = minuto;
		Posicion = posicion;
		Coment = coment;
		Accion = accion;
	}
	
	
}
