package fut;

import javax.swing.JButton;

public class DatosBoton {
	public int x1;
	public int x2;
	public int y1;
	public int y2;
	public String nombre;
	public JButton boton;
	
	public DatosBoton(int x1, int y1, int x2, int y2, String nombre) {
		super();
		this.x1 = x1;
		this.x2 = x2;
		this.y1 = y1;
		this.y2 = y2;
		this.nombre = nombre;
		this.boton=new JButton(nombre);
		boton.setName(nombre);
		boton.setBounds(x1,y1,x2,y2);
		
	}
	
	

}
